var childHeight = 53;
function displayIfChildIsAbleToRideTheRollerCoaster() {
    if  (childHeight > 52){
    console.log("Get on that ride, kiddo!");
    }
    else {
    console.log("Sorry Kiddo. Maybe next year.");
    }
}
displayIfChildIsAbleToRideTheRollerCoaster()
